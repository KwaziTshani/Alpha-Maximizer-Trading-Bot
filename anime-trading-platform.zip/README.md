# Anime Trading Platform

Anime-styled trading platform using React, Tailwind, and Polygon API.